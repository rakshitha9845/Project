import { Update } from './update';

describe('Update', () => {
  it('should create an instance', () => {
    expect(new Update()).toBeTruthy();
  });
});
