import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Student } from '../student';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.css']
})
export class DeleteComponent implements OnInit {
  delete(){
    alert("deleted data successfully!!!")
  }

  id!:string;
  
  constructor( private httpClient:HttpClient) { }
  ngOnInit(): void {}
  onSubmit(data:Student)
  {
    this.httpClient.post('http://localhost:8089/api/deletestudent/' + `${data.id}`,data).subscribe((result)=>
    {
    console.warn("result",this.id);
    console.warn(data);
  })
}


}

  
    // this.studentService.getStudents().subscribe((data:Student[])=>
    // {
    //   console.log(data);
    //   this.students = data;
    // }
    // );
  

    

    

  // ngOnInit(): void {
    // this.studentService.getStudents().subscribe((data:Student[])=>
    // {
    //   console.log(data);
    //   this.students = data;
    // }
    // );
  // }


