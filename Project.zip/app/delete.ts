export class Delete {
    id!:string;
    name!:string;
    email!: string;
    course!:string;
}


