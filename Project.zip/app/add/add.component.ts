import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Student } from '../student';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  add(){
    alert("data  added successfully!!!")
  }

  students!:Student[];
  getStudents: any;
  constructor(private studentService:StudentService, private https:HttpClient) { }
  onSubmit(data:Student)
  {
    this.https.post('http://localhost:8089/api/student',data).subscribe((result)=>
    console.warn("result",result));
    console.log(data);
  }

  ngOnInit(): void {
    this.studentService.getStudents().subscribe((data:Student[])=>
    {
      console.log(data);
      this.students = data;
    }
    );
  }

}
